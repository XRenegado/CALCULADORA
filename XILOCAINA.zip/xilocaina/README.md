# App Calculadora IMC
_O aplicativo é uma calculadora de IMC onde você pode avaliar seu índice de massa corporal baseado na informação relevante no peso de corpo, na altura do indivíduo._
---
_Imagens do App_
---
![device-2021-02-24-221838](https://user-images.githubusercontent.com/72363971/109090024-149d9680-76f1-11eb-83af-2bb904764518.png)
![device-2021-02-24-221950](https://user-images.githubusercontent.com/72363971/109090107-372faf80-76f1-11eb-8b46-1d481f770c3c.png)


Se as informações deste repositório foram úteis para você de alguma forma, certifique-se de dar uma estrela 🌟, dessa forma, outras pessoas podem encontrá-lo e se beneficiar também!
