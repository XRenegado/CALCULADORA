package br.com.gilbercs.appimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SobreActivity extends AppCompatActivity {
    private TextView descricaApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre);
        descricaApp = (TextView)findViewById(R.id.idDescricao);
        descricaApp.setText("Descrição do Aplicativo:" +
                "\n\n"+"O aplicativo é uma calculadora de IMC" +
                "\n"+"onde você pode avaliar seu índice de massa" +
                "\n"+"corporal baseado na sua altura e peso." +
                "\n\n"+"Nome App: Calculadora de IMC" +
                "\n"+"Modelo: Android" +
                "\n"+"Marca: XR Technology" +
                "\n"+"Desenvolvedor: Eduardo Pereira Boeira");
    }
}